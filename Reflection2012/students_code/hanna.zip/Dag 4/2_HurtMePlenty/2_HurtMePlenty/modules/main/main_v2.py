class main_v2:

    endFound = False
    
    def setDependencies(self, modules):
        self.maze = modules.getModule("mparser")
        self.astar = modules.getModule("astar")
        self.visu = modules.getModule("visualization")
    def calculateH(self, current, end):
        xDistance = abs(current[0] - end[0])
        yDistance = abs(current[1] - end[1])
        if (xDistance > yDistance):
           H = 14*yDistance + 10*(xDistance-yDistance)
        else:
           H = 14*xDistance + 10*(yDistance-xDistance)
        return H
    def checkNb(self, index, openList, closedList, ignore, parents, gScore, start, end):
        print "index is"
        print index
        
        neighbour = openList[index]
        if ignore.count(neighbour) == 0: # check if the neighbour is on the ignore list
            if openList.count(neighbour) == 0: # add neighbour to the open list if not present already
                openList.append(neighbour)
            
            parents[tuple(neighbour)] = start # make the current square the parent of this neighbour
            
            gScore += 10 # Add 10 to the G score
             
            hScore = self.calculateH(neighbour, end) # get the H score
            
            fScore = gScore + hScore  # get the F score
            
            if neighbour == end:
                 self.endFound = True;
                 print "end was found"
                        
        return fScore
    def start(self):
        self.visu.init()
        
        edges, moves = self.maze.parseMaze(filename = "./maze.txt")
        self.maze.prettyPrint(edges)
        
        startPoint = (0, 0)
        endPoint = (3, 0)
        
        toCheck = moves[startPoint]
        visited = []
        ignoreList = [(0, 3), (3, 3)]
        parentList = {}
        fList = []
        g = 0
        
        currentNode = startPoint
        
        while len(toCheck) > 0:
            if self.endFound == True:
                    break
            nrOfNeighbours = len(toCheck) # get the number of neighbours
            print "neighbours"
            print nrOfNeighbours
            nrOfNeighbours - 1
            print "neighbours"
            print toCheck
            i = 0
            
            for i in range (0, nrOfNeighbours):
                fValue = self.checkNb(i, toCheck, visited, ignoreList, parentList, g, startPoint, endPoint) 
                print fValue
                
                fList.append(fValue)
                index = fList.index(min(fList))
                visited.append(currentNode)
                toCheck.remove(currentNode)
                toCheck.insert(0, toCheck[index])

 
        self.visu.visualize(edges, [], [], (0,0), (3,0), scale = (50,50), offset = (50, 50))
        
