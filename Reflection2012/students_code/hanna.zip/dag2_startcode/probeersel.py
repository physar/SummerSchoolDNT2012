	img = getSnapshot()
	startplaatje = img[0]
	size = (320,240)
	minHSV = [x, x, x]
	maxHSV = [y, y, y]
	
filterImage(self, img, minHSV, maxHSV):

	minScaler = cv.Scaler(minHSV[0], minHSV[1], minHSV[2], 0)
	maxScaler = cv.Scaler(maxHSV[0], maxHSV[0], maxHSV[2], 0)
	
	resultImg = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
	endresultImg = cv.InRangeS(img, minScaler, maxScaler, resultImg)
	return endresultImg
	
saveImage('resultaat.jpg', filterImage())
	