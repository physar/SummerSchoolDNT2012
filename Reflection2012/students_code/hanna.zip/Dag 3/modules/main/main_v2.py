class main_v2:
    def setDependencies(self, modules):
        self.maze = modules.getModule("mparser")
        self.astar = modules.getModule("astar")
        self.visu = modules.getModule("visualization")
    def calculateCosts(self, begin, end):
        xDistance = abs(begin[0] - end[0])
        yDistance = abs(begin[1] - end[1])
        if (xDistance > yDistance):
           H = 14*yDistance + 10*(xDistance-yDistance)
        else:
           H = 14*xDistance + 10*(yDistance-xDistance)
        return H
     def test(self, string):
        if string == "hoi"
            return 1;
        else
            return "doei";
    def start(self):
        test("hoi")
        self.visu.init()
        
        edges, moves = self.maze.parseMaze(filename = "./maze.txt")
        self.maze.prettyPrint(edges)
        
        startPoint = moves[0,3]
        endPoint = moves[0,0]
        
        toCheck = [startPoint]
        #visited = []
        
        print len(moves[0.3])
        
        
        
        '''voor alle elementen in de open lijst:
        f = g + h
        
        controleer het element met de laagste f waarde
        
        doe voor dit punt bovenstaande procedure opnieuw'''
 
        self.visu.visualize(edges, [], [], startPoint, endPoint, scale = (50,50), offset = (50, 50))
        
