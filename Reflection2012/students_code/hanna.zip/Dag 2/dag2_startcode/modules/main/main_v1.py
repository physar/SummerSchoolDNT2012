class main_v1:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")
    
    def start(self):
        self.globals.setProxies()
        self.motion.init()
        self.motion.standUp()
        self.tools.cSubscribe()
        
        
        orangeMin = [6, 17, 72]
        orangeMax = [17, 238, 220]

        #Make an image
        (image, (headInfo)) = self.tools.getSnapshot()
        
        self.tools.SaveImage("beforeImage.png", image) 
        
        resultImg = self.vision.filterImage(image, orangeMin, orangeMax)
        
        self.tools.SaveImage("filteredImage.png", resultImg)

        self.vision.findCircle(resultImg)
        
        #Throug extended research at the cost of many fallen Nao's
        #we at the Dutch Nao Team found that the optimal head position is
        self.motion.setHead(0,-0.5)