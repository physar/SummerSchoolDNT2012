import cv, cv2
import numpy, math

class vision_v1():    
    globals = None

    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.tools = modules.getModule("tools")

    #Filter HSV Image with given values
    def filterImage(self, img, minHSV, maxHSV):
        size = (320, 240)
        
        #Make image compatible with openCV
        minScaler = cv.Scalar(minHSV[0], minHSV[1], minHSV[2], 0)
        maxScaler = cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2], 0)
        
        #Filter the image
        resultImg = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        
        #Convert to a decent image format
        cv.InRangeS(img, minScaler, maxScaler, resultImg)
        
        self.tools.SaveImage("progressImage.png", resultImg)
        
        cv.Smooth(resultImg, resultImg, cv.CV_MEDIAN, 3)
        
        resultImage = cv.GetMat(resultImg)
        
        return resultImage
        
           #Find a Blob with a color at two positions in the spectrum
    def filterImageDouble(self, img, minHSV1, maxHSV1, minHSV2, maxHSV2):
        '''
        Input: HSV Image
        Output: Black White Matrix/Image      
        '''
        # Size of the images
        size = (320,240)
                
        filtIm1 = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        filtIm2 = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        filterdIm = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)

        #Color scalars
        [hMin1, sMin1, vMin1] = minHSV1
        [hMax1, sMax1, vMax1] = maxHSV1
        [hMin2, sMin2, vMin2] = minHSV2
        [hMax2, sMax2, vMax2] = maxHSV2
        hsvMin1 = cv.Scalar(hMin1, sMin1, vMin1, 0)
        hsvMax1 = cv.Scalar(hMax1, sMax1, vMax1, 0)  
        hsvMin2 = cv.Scalar(hMin2, sMin2, vMin2, 0)
        hsvMax2 = cv.Scalar(hMax2, sMax2, vMax2, 0)  

        # Color detection using HSV
        cv.InRangeS(img, hsvMin1, hsvMax1, filtIm1)
        cv.InRangeS(img, hsvMin2, hsvMax2, filtIm2)
        
        #combine images
        cv.Or(filtIm1, filtIm2, filterdIm)
        
        #smooth and return
        cv.Smooth(filterdIm, filterdIm, cv.CV_MEDIAN, 5)
        filtImMat = cv.GetMat(filterdIm)
        return filtImMat
     # Proces image to detect color blobs
    def getBlobsData(self, image):
        '''
        Input: Image
        Return: numberOfBlobsFound , [List [x,y-pixels] of 
        '''
        minHSVBlue   = [110, 214, 100]
        maxHSVBlue   = [120, 238, 217]
        minHSVOrange = [  6, 171,  72]
        maxHSVOrange = [ 17, 238, 220]
        minHSVPink1  = [  0, 148,  77]
        maxHSVPink1  = [  7, 237, 217]
        minHSVPink2  = [174, 148,  77]
        maxHSVPink2  = [181, 237, 217]
        
        #filter image with given HSV
        filtImageB = self.filterImage(image, minHSVBlue, maxHSVBlue)
        filtImageO = self.filterImage(image, minHSVOrange, maxHSVOrange)
        filtImageP = self.filterImageDouble(image, minHSVPink1, maxHSVPink1, minHSVPink2, maxHSVPink2)
        
        #Find Circles (should only be 1 per image ) Blobs = (x,y)
        blobsP = self.findCircle(filtImageP)
        blobsB = self.findCircle(filtImageB)
        blobsO = self.findCircle(filtImageO)
        
        blobsFound , blobsList = self.appendBlobs( blobsP, blobsB, blobsO)
        return blobsFound , blobsList
    #Find Circle in a filtered image
    def findCircle(self,imageMat):
        '''
        Input: Black Whit Image
        Return: List of center position of found Circle       
        '''
        imagenp = numpy.asarray(imageMat)
        print imagenp
         
        coordinates = []
        dp = 2
        minDist =120
        param1 = 255
        param2 = 27
        minSize = 8
        maxSize = 300
        circles = cv2.HoughCircles(imagenp,cv.CV_HOUGH_GRADIENT,dp,minDist, None,param1,param2,minSize, maxSize)
        #DEBUG
        print 'Found circles: ' + str(circles)

        if circles is not None:
            for i in xrange(len(circles[0])):
                radius = circles[0][ i][2]
                center = [circles[0][ i][0], circles[0][ i][1]]
                print 'Found radius and center'
                print (radius, center)
                coordinates.append(center)
                
        if circles == None:
            return None
        else:
            return coordinates
            
    # Proces image to detect color blobs
    def getBlobsData(self, image):
        '''
        Input: Image
        Return: numberOfBlobsFound , [List [center-pixels] of blobs]
        '''
        return blobsFound , blobsList
        
    # Get Average Distance between multiple blobs  
    def calcAvgBlobDistance(self, blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: Avarege Distance in pixels
        '''
        return Distance
    
    # Find centre of a Landmark
    def calcMidLandmark(self, blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: center pixel as (x,y)
        '''
        return center
        
    # Find the angle between a found Landmark and the Nao
    def calcAngleLandmark(self, center):
        '''
        Input: center pixel, (x,y)
        Output: Angle in radians
        '''    
        return angle
    
    # Find the Signature
    def findSignature(self,blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: Signature
        '''
        return signature

    