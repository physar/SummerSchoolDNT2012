import time

class main:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion_v1 = modules.getModule("motion_v1")
        self.tools = modules.getModule("tools")
        
    def walkAround(self):
        self.motion_v1.walkTo(1, 0, 0)
        self.motion_v1.walkTo(0, 1, 0)
        self.motion_v1.walkTo(-1, 0, 0)
        self.motion_v1.walkTo(0, -1, 0)
        
    def walkAroundAngle(self):
        self.motion_v1.walkTo(1, 0, 0)
        self.motion_v1.walkTo(0, 0, 1.57)
        self.motion_v1.walkTo(1, 0, 0)
        self.motion_v1.walkTo(0, 0, 1.57)
        self.motion_v1.walkTo(1, 0, 0)
        self.motion_v1.walkTo(0, 0, 1.57)
        self.motion_v1.walkTo(1, 0, 0)
        self.motion_v1.walkTo(0, 0, 1.57)
    def walkCircle(self):
        self.motion_v1.walkTo(0, 1, 3)
    def walkInMaze(self):
        self.motion_v1.walkTo(0.5, 0, 0)
        self.motion_v1.walkTo(0, 0, 1.30)
        self.motion_v1.walkTo(0.6, 0, 0)
        self.motion_v1.walkTo(0, 0, -1.30)
        self.motion_v1.walkTo(0.9, 0, 0)
        self.motion_v1.walkTo(0, 0, -1.30)
        self.motion_v1.walkTo(1, 0, 0)
        
    def walkStuk1(self):
        self.motion_v1.walkTo(0.5, 0, 0)
    
    def walkStuk2(self):
        self.motion_v1.walkTo(0, 0, 1.30)
        
    def start(self):
        self.globals.setProxies()
        self.globals.speechProxy.say("Hello World")
        self.motion_v1.init()
        self.motion_v1.stiff()
        self.motion_v1.standUp()
        
        self.globals.redBallProxy.startTracker()
        
        reachedBall = False
        positionList = []

        while reachedBall == False:
            positionList = self.globals.redBallProxy.getPosition()
            if positionList[0] < 0.10:
		        reachedBall = True
            else:                
		        self.motion_v1.walkTo(positionList[0],positionList[1],0)
                
        self.globals.redBallProxy.stopTracker()
        #self.globals.redBallProxy.startTracker()
        #positionList = self.globals.redBallProxy.getPosition()
        #self.motion_v1.walkTo(positionList[0],positionList[1],0)
        
        #self.globals.redBallProxy.stopTracker()
        
        #self.walkAround()
        #self.walkAroundAngle()
        #self.walkCircle()
        #self.walkInMaze()
        #self.motion_v1.walkTo(1, 0, 0)
        #self.motion_v1.walkTo(0, 1, 0)
        #self.motion_v1.walkTo(-1, 0, 0)
        #self.motion_v1.walkTo(0, -1, 0)