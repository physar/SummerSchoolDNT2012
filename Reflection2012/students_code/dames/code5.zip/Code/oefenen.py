def functie2():
	print "Functie 2!"
	
def functie1():
	print "Functie 1!"
	
functionlist = [functie1, functie2]

for i,value in enumerate(functionlist):
	if standUp() == True:
	    value()
	elif standUp() == False:
		standUp()
		value()
