import cv

class main_v1:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")

    def start(self):
        self.globals.setProxies()
        self.motion.init()
        self.tools.cSubscribe()
        
        self.motion.stiff()
        self.motion.normalPose()
        
        #Throug extended research at the cost of many fallen Nao's
        #we at the Dutch Nao Team found that the optimal head position is
        self.motion.setHead(0,-0.5)
        
        finished = False
        
        while(finished == False):
            if self.motion.standUp():
                finished = True
                print 'Fallen'
            #when hitting a wall walk backwards   
            #NOTE: set memProxy aan in globals!!
            if ((self.globals.memProxy.getData("LeftBumperPressed", 0) != 0.0) or \
                (self.globals.memProxy.getData("RightBumperPressed", 0) != 0.0)):
                print "Stop hitting the wall"
                self.motion.walkTo(-0.4,0,0)
                
            #get snapshot from robot
            img = self.tools.getSnapshot()
            
            (image, (camPos, headAngles)) = img 
            
            blobsFound , blobsList = self.vision.getBlobsData(image)
            
            for i in xrange(len(blobsList)):
                if blobsList[i] !=None:
                    [center, radius] = blobsList[i]
                    blobsList[i] = [center]
                    image = cv.Circle(image, center, radius, (255, 255, 255), 3, 8, 0)
            title = str(i)+'zien.png'
            print title
            cv.SaveImage(title, image)
                
            '''if blobsFound > 1:
                center = self.vision.findSignature(blobsList , blobsFound)
                walkAngle = self.vision.calcAngleLandmark(center)
                self.motion.walkTo(1, 0, walkAngle)'''
            '''if blobsFound <= 1:
                self.motion.walkTo(0.2,0,0)
            if blobsFound > 1:
                afstand = self.vision.calcAvgBlobDistance(blobsList, blobsFound)
                print str(afstand)
                if afstand < 60:
                    finished = True
                midden = self.vision.calcMidLandmark(blobsList, blobsFound)
                print str(midden)
                hoek = self.vision.calcAngleLandmark(midden)
                self.motion.walkTo(0.2, 0, hoek)
                print str(hoek)
            
                richting = self.vision.findSignature(blobsList,blobsFound)
                print str(richting)'''
            finished = True
            
			