class main:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
    
    def start(self):
        self.globals.setProxies()
        #self.globals.speechProxy.say("Hello World")
        self.motion.init()
        self.motion.standUp()
        #self.vierkant()
        #self.vierkantDraaien()
        #self.rondje()
        # volg rode bal
        self.tools.cSubscribe()
        self.globals.redBallProxy.startTracker()
        while (not self.motion.standUp()):
            position = self.globals.redBallProxy.getPosition()
            self.motion.walkTo(position[0], position[1], 0)
            
        
    def vierkant(self):
        # naar voren
        self.motion.walkTo(0.5, 0 , 0)
        self.motion.standUp()
        # naar links
        self.motion.walkTo(0, 0.5, 0)
        self.motion.standUp()
        self.motion.walkTo(-0.5, 0, 0)
        self.motion.standUp()
        self.motion.walkTo(0, -0.5, 0)
        self.motion.standUp()        

    def vierkantDraaien(self):
        x = 0
        while (x != 4): 
            self.motion.standUp()
            # naar voren
            self.motion.walko(0.5, 0 , 0)
            #draaien
            self.motion.walkTo(0, 0.5, (3.14/2))
            x = x+1
            
    def rondje(self):
        y = 0
        while (y != 10):
            self.motion.standUp()
            self.motion.walkTo(0, 0.1, (6.28/5))
            y = y+1
            
    def doolhof(self):
        pass