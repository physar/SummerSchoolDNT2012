import math

class main_v1:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")

    def start(self):
        self.globals.setProxies()
        self.motion.init()
        self.tools.cSubscribe()
        
        self.motion.stiff()
        self.motion.normalPose()
        
        #Throug extended research at the cost of many fallen Nao's
        #we at the Dutch Nao Team found that the optimal head position is
        self.motion.setHead(0,-0.5)
        
        finished = False
        
        while(finished == False):
            if self.motion.standUp():
                finished = True
                print 'Fallen'
            #when hitting a wall walk backwards   
            #NOTE: set memProxy aan in globals!!
            if ((self.globals.memProxy.getData("LeftBumperPressed", 0) != 0.0) or \
                (self.globals.memProxy.getData("RightBumperPressed", 0) != 0.0)):
                print "Stop hitting the wall"
                self.motion.walkTo(-0.4,0,0)
            
            # (x,y)  (x,y)
            # while ((x[0]- x[2]) != 76):
            # walkTo (x, y, rad)
            
            #get snapshot from robot
            img = self.tools.getSnapshot()
            
            (image, (camPos, headAngles)) = img 
            
            blobsFound , blobsList = self.vision.getBlobsData(image)
            
            distance = None
            if blobsFound > 1:
                if blobsFound == 2:
                    newList = blobsList
                    newList.remove(None)
                    distance = self.vision.calcAvgBlobDistance(newList)
                    print "Distance" + str(distance)
                    
                else:
                    dist1 = self.vision.calcAvgBlobDistance([blobsList[0],  blobsList[1]])
                    dist2 = self.vision.calcAvgBlobDistance([blobsList[0],  blobsList[2]])
                    dist3 = self.vision.calcAvgBlobDistance([blobsList[1],  blobsList[2]])
                    
                    distance = (dist1 + dist2 + dist3) /3
                    print "Distance" + str(distance)
                    
            #arrived = False        
            #while (arrived == False):
            
            if distance>73 and distance<83:
                #self.motion.walkTo (0, 0, 0.5*math.pi)
                direction = self.vision.findSignature(blobsList)
                if direction == "left":
                    self.motion.walkTo (0, 0, 0.5*math.pi)
                if direction == "right":
                    self.motion.walkTo (0, 0, -0.5*math.pi)
                if direction == "top":
                    self.globals.speechProxy.say("I'm at the finish!")
                #finished = True
            else:
                self.motion.walkTo (0.05, 0, 0)
                
            