import sys
import math
import bisect
import copy

import copy

class aStar_v1:
    def setDependencies(self, modules):
        self.visu = modules.getModule("visualization")
       
    
    #a-star main-loop
    def findShortestPath(self, start, end, validMoves, edges):
        #Set variables
        startPath = [self.getCost(start, end), [start]]
        pathList = [startPath]
        seen = []
        finished = False
        currentPath = [0,[]]
        
        while finished == False:
            if len(pathList) == 0:
                finished = True
                path = currentPath[1]
            currentPath, finished = self.getNext(pathList, seen, end, finished)
            self.addNewPath(validMoves, currentPath, end, pathList, seen)
            path = currentPath[1]
            self.visu.visualize(edges, path, seen, start, end, scale=(50,50), offset=(100,100))
            print pathList
            
        path = currentPath[1]
        if currentPath == [0,[(0,0)]]:
            print 'Plek niet bereikbaar!'
        return path, seen
        
        #Zoek de volgende node die bekeken moet worden
    def getNext(self, pathList, seen, end, finished):
        for i in pathList:
            for node in seen:
                if i[1][-1] == node:
                    print i,pathList
                    if i in pathList:
                        pathList.remove(i)
        if len(pathList) > 0:
            currentPath = pathList[0]
        else:
            currentPath = [0,[(0,0)]]
        if currentPath[1][-1] == end:
            finished = True
            print 'Einde gevonden:'
            print currentPath[1]
        return currentPath, finished
        
        #Voeg de nieuwe paden toe die bij de gevonden node horen
        #En voeg node toe aan seen map
    def addNewPath(self, validMoves, currentPath, end, pathList, seen):
        if len(pathList) > 0:
            neighbours = self.getNeighbours(validMoves, currentPath[1][-1])
            if len(neighbours) != 0:
                for i in neighbours:
                    estimatedCost = self.getCost(i, end)
                    currentHeur = len(currentPath[1])
                    newPath = copy.deepcopy(currentPath)
                    newPath[0] = copy.deepcopy(currentHeur) + copy.deepcopy(estimatedCost)
                    newPath[1].append(i)
                    bisect.insort(pathList, copy.deepcopy(newPath))
                pathList.remove(currentPath)
                seen.append(copy.deepcopy(currentPath[1][-1]))

        #Krijg de geschatte afstand van een punt tot het eindpunt
    def getCost(self, node1, node2):
        x = node1[0] - node2[0]
        y = node1[1] - node2[1]
        cost = math.sqrt(x**2 + y**2)
        
        return cost

        #Zoek de bijbehorende buren  
    def getNeighbours(self, validMoves, node):
        neighbours = []
        for x,y in validMoves[node]:
            neighbours.append((x,y))
        return neighbours

    #OPTIONAL:
    # Insert the new paths into the priority queue
    def addToQueue(self, queue, newPaths):
        pass
   
        '''
        Input:
            - queue     : A list containing Tuples or Lists sorted in ascending order
                          by the first value of each Tuple/List.
            - newPaths  : List that contains the same datatypes as 'queue' (Tuples or Lists).
        Output:
            - None. (The queue passed to this function will be edited.)
            
        Each path in 'newPaths' is inserted into 'queue' according to its first element.
        Example:
        queue = [(1, ':D'), (3, ':P')]
        newElement = (2, '^_^')
        print 'before: ', queue
        bisect.insort(queue, newElement)
        print 'after: ', queue
        ---------
        before: [(1, ':D'), (3, ':P')]
        after: [(1, ':D'), (2, '^_^'), (3, ':P')]
        '''