class main_v2:
    def setDependencies(self, modules):
        self.maze = modules.getModule("mparser")
        self.astar = modules.getModule("astar")
        self.visu = modules.getModule("visualization")

    def start(self):
        self.visu.init()
        
        edges, validMoves = self.maze.parseMaze()
        self.maze.prettyPrint(edges)
        start = (0, 0)
        end = (6, 8)
        
        path, seen = self.astar.findShortestPath(start, end, validMoves, edges)
        self.visu.visualize(edges, path, seen, start, end, scale=(50,50), offset=(100,100))

        
        #findShortestPath(self, start, end, validMoves):
        #def visualize(self, edges, path, seen, start, end, scale=(100,100), offset=(100,100)):
        
        