class main:
	def setDependencies(self, modules):
		pass
		
	def start(self):
		pass
	def init(self):
		pass
		