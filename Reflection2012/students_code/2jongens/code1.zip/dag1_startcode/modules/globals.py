from naoqi import ALProxy

class globals :
    IP_ADDRESS = "192.168.1.32"
    PORT = 9559
    
    def setDependencies(self, modules) :
        pass
        
    def setProxies(self) :
        self.speechProxy = ALProxy("ALTextToSpeech", self.IP_ADDRESS, self.PORT)
        self.motProxy = ALProxy("ALMotion", self.IP_ADDRESS, self.PORT)
        self.posProxy = ALProxy("ALRobotPose", self.IP_ADDRESS, self.PORT)
        self.vidProxy = ALProxy("ALVideoDevice", self.IP_ADDRESS, self.PORT)
        self.redBallProxy = ALProxy("ALRedBallTracker", self.IP_ADDRESS, self.PORT)