from naoqi import ALProxy

class globals:
    wolf = "192.168.1.32"
    hector = "192.168.1.53"
    ipadress = wolf
    PORT = 9559
    BLUE_MIN_HSV = [110, 214, 100]
    BLUE_MAX_HSV = [120, 230, 217]
    ORANGE_MIN_HSV = [6, 171, 72]
    ORANGE_MAX_HSV = [17, 238, 220]
    PINK_MIN1_HSV = [0, 148, 77]
    PINK_MAX1_HSV = [7, 237, 217]
    PINK_MIN2_HSV = [174, 148, 77]
    PINK_MAX2_HSV = [181, 237, 217]
    MIN_HSV_ARRAY = (ORANGE_MIN_HSV, BLUE_MIN_HSV, PINK_MIN1_HSV, PINK_MIN2_HSV)
    MAX_HSV_ARRAY = (ORANGE_MAX_HSV, BLUE_MAX_HSV, PINK_MAX1_HSV, PINK_MAX2_HSV)
    
    SNAPSHOT_RESOLUTION = (320,240)
    
    
    
    def setDependencies(self, modules):
        pass

    def setProxies(self):
        self.motProxy = ALProxy("ALMotion", self.ipadress, self.PORT)
        self.posProxy = ALProxy("ALRobotPose", self.ipadress, self.PORT)
        self.vidProxy = ALProxy("ALVideoDevice", self.ipadress, self.PORT)
        
        self.speechProxy = ALProxy("ALTextToSpeech", self.ipadress, self.PORT)
        self.memProxy = ALProxy( "ALMemory", self.ipadress, self.PORT) 
        self.ledProxy = ALProxy( "ALLeds", self.ipadress, self.PORT)