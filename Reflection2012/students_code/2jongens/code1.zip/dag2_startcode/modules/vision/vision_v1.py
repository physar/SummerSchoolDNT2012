import cv, cv2
import numpy, math

class vision_v1():    
    globals = None

    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")

    #Filter HSV Image with given values
    def filterImage(self, img, minHSV, maxHSV):
        
        minScalar = cv.Scalar(minHSV[0], minHSV[1], minHSV[2], 0)
        maxScalar = cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2], 0)
        
        result = cv.CreateImage(self.globals.SNAPSHOT_RESOLUTION, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScalar, maxScalar, result)
        cv.Smooth(result, result, cv.CV_MEDIAN, 3)
        
        return cv.GetMat(result)
        
    #Find Circle in a filtered image
    def findCircle(self, filteredImage):
        img = numpy.asarray(filteredImage)
        
        circles = cv2.HoughCircles(img, cv.CV_HOUGH_GRADIENT, 2, 120, None, 255, 27, 9, 300)
        
        if circles == None:
            return None
        else:
            return (circles[0][0][0], circles[0][0][1])
            
            
    # Proces image to detect color blobs
    def getBlobsData(self, image):
        
        circles = []
        
        for i in xrange(3) :
            filteredImg = self.filterImage(image, self.globals.MIN_HSV_ARRAY[i], self.globals.MAX_HSV_ARRAY[i])
  
            if i == 2 :
                filteredImg2 = self.filterImage(image, self.globals.MIN_HSV_ARRAY[3], self.globals.MAX_HSV_ARRAY[3])
                cv.Or(filteredImg, filteredImg2, filteredImg)
                
            circles.append(self.findCircle(filteredImg))
            
            
        result = []
        
        for i in xrange(3) :
            if circles[i] :
                result.append((circles[i],i))
            
        return len(result), result
        
    # Get Average Distance between multiple blobs  
    def calcAvgBlobDistance(self, blobList):
        '''
        Input: [BLUE, ORANGE, PINK]
        Output: Avarege Distance in pixels
        '''
        if len(blobList) <= 1 :
            return None
            
        elif len(blobList) == 2:
           return self.calcBlobDistance(blobList)
        
        else :
            sum = 0
            for i in xrange(2) :
                sum += self.calcBlobDistance((blobList[i], blobList[i+1]))
                
            sum += self.calcBlobDistance((blobList[0], blobList[2]))
            return sum / 3
    
    def calcBlobDistance(self, blobs) :
        a = (blobs[0][0][0] - blobs[1][0][0])
        b = (blobs[0][0][1] - blobs[1][0][1])
        
        return math.sqrt(a**2 + b**2)
        
        
   
    # Find centre of a Landmark
    def calcMidLandmark(self, blobList):
        '''
        Input: [BLUE, ORANGE, PINK]
        Output: center pixel as (x,y)
        '''
        if len(blobList) == 0 or len(blobList) == 1:
            return None
        
        if len(blobList) == 2:
            return (blobList[0][0][0] + blobList[1][0][0])/2
        else :
            return (blobList[1][0][0] + blobList[2][0][0])/2
            
        
    # Find the angle between a found Landmark and the Nao
    def calcAngleLandmark(self, center):
        '''
        Input: center pixel, (x,y)
        Output: Angle in radians
        '''    
        
        if center :
            return (center - (320/2)) * 0.0038
        
        return 0
    
    # Find the Signature
    def findSignature(self, blobList):
        '''
        Input: [BLUE, ORANGE, PINK]
        Output: Signature
        '''
        if len(blobList) == 1: 
            return -1
        
        if len(blobList) == 2 :
            if blobList[0][1] == 1 :
                if blobList[0][0][0] <= blobList[1][0][0] :
                    return "left"
                else :
                    return "right"
            elif blobList[1][1] == 1:
                if blobList[1][0][0] <= blobList[0][0][0] :
                    return "left"
                else :
                    return "right"
   
        
        if (blobList[1][0][1] <= blobList[0][0][1] and blobList[1][0][1] <= blobList[2][0][1]) :
            return "finish"
        elif blobList[1][0][0] <= blobList[2][0][0] :
            
            return "left"
        elif blobList[1][0][0] >= blobList[2][0][0] :
            return "right" 
       
        
        
        return -1

    