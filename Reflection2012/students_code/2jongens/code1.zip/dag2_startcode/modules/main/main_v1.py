import math, time

class main_v1:

    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")
        self.behaviour = modules.getModule("behaviour")

    def start(self):
        self.globals.setProxies()
        self.motion.init()
        self.globals.speechProxy.say("Activated")
        
        self.motion.stiff()
        
        self.motion.standUp()
        self.motion.normalPose()
        
        self.motion.setHead(0,-0.5)
        self.tools.cSubscribe()
       
        
        
        while True:
            self.motion.setWalkTargetVelocity(1, 0, 0.03, 1) #hector -0.07, wolf 0.03
            
            self.walkMaze()
            img = self.tools.getSnapshot()[0]
            blobList = self.vision.getBlobsData(img)
            
            
            sig = self.vision.findSignature(blobList[1])
            self.globals.speechProxy.say("New landmark reached. " + str(sig))
        
            if sig == "left" :
                self.motion.walkTo(0, 0, .5*math.pi)
            elif sig == "right" :
                self.motion.walkTo(0, 0, -.5*math.pi)
            elif sig == "finish" :
                self.globals.speechProxy.say("Mission Accomplished")
                break
                
        
        
        self.motion.setWalkTargetVelocity(0,0,0,0)
        
    def walkMaze(self) :
        while True :
            img = self.tools.getSnapshot()[0]
            blobList = self.vision.getBlobsData(img)
            
                
            blobDist = self.vision.calcAvgBlobDistance(blobList[1]) 
          
            angle = self.vision.calcAngleLandmark(self.vision.calcMidLandmark(blobList[1]))
            test = False
            
            if abs(angle) > .15 :
                self.motion.setWalkTargetVelocity(0,0,0,0)
                test = True
                self.motion.walkTo(0, 0, -1*angle) 
            
            print(angle)
            
            if blobDist and blobDist > 80 :
                self.motion.killWalk()
                return
                
            if test :
                self.motion.walkTo(.15, 0, 0)
      
 
        
        