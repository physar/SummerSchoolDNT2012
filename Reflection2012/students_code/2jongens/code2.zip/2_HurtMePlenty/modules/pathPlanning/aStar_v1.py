import math

class aStar_v1:
    def setDependencies(self, modules):
        pass
    
    #check wikipedia for pseudo-code:
    #http://en.wikipedia.org/wiki/A*_search_algorithm
    #Good luck!