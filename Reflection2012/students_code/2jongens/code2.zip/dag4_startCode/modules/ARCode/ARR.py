import cv
import numpy as np
import ARimport as ar
import cv2 #import de opencv/numpy en AR code recognition library

class ARR :
    
    def setDependencies(self, modules) :
        pass
    
    def readMarker(self, image) :
        ARcode = ar.ARimport() #maak een nieuwe AR detectie object
        image = cv.LoadImage(image ,cv.CV_LOAD_IMAGE_COLOR) #laad het testplaatje
        im_array = np.asarray( image[:,:] ) #maak van de opencv image een numpy array
        ARcode.setOutputFileName("output.png") #Ze de naam voor de output file
        ARcode.setShowOutput(True) #zeg dat het algoritme output moet tonen, kan je ook uitzetten
        returnint = ARcode.findMarkers(im_array) #vind de markers in het plaatje, returned hoeveel markers gevonden zijn
        
        output = ARcode.getFoundMarker(0) #input < returnint # 0 is voor de eerste marker 1 voor de 2e etc. # output structs met .x .y en .ID informatie
        if output.ID == 4294967295L :
            return None
        #print((output.ID, output.x, output.y))
        return (output.ID, output.x, output.y)
        