from math import pi

class main :
    
    def setDependencies(self, modules) :
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        
    
    def start(self) :
        self.globals.setProxies()
        self.globals.speechProxy.say("Activated")
        self.motion.init()
        
        self.motion.stiff()
        self.motion.normalPose(True)
        self.tools.cSubscribe()
        self.globals.redBallProxy.startTracker()
        self.tools.SaveImage("test.jpg", self.tools.getSnapshot()[0])

        
        
        while True :
            
            headPos = self.motion.getHeadPos()
            self.motion.walkTo(0, 0, headPos[0])
            self.motion.changeHead(0, 0) 
           # if self.globals.redBallProxy.isNewData() :
           # self.motion.killWalk(True)
            pos = self.globals.redBallProxy.getPosition()
            self.walkTo(pos)
        
        
            
            
          
        
        #print(self.globals.redBallProxy.getPosition())
        #self.walkTo(self.globals.redBallProxy.getPosition())
        
        #self.tools.SaveImage("test.jpg", self.tools.getSnapshot()[0])
        self.globals.redBallProxy.stopTracker()
        
       
    def walkTo(self, pos) :
        self.motion.walkTo(int(pos[0]/2), pos[1], 0)
        
        
    def walkSquare(self) :
        self.motion.walkTo(.2, 0, 0)
        self.motion.walkTo(0, 1, 0)
        self.motion.walkTo(-1, 0, 0)
        self.motion.walkTo(0, -1, 0)
        
        
    def walkSquareWithTurn(self) :
        for i in xrange(4) :
            self.motion.standUp()
            
            self.motion.walkTo(.2, 0, 0)
            self.motion.walkTo(0, 0, .5*pi)
            
    def walkCircle(self, diameter) :
        self.motion.walkTo(2, 0, 0.75*pi) 
        
    def walkMaze(self) :
        
        self.forwardWithCorrection(1.8)
        self.motion.walkTo(0, 0, .5*pi)
        self.forwardWithCorrection(1)
        self.motion.walkTo(0, 0, .5*pi)
        self.forwardWithCorrection(1)
        self.motion.walkTo(0, 0, -.5*pi)
        self.forwardWithCorrection(1)
        self.motion.walkTo(0, 0, .5*pi)
        self.forwardWithCorrection(1)
   
    
    def forwardWithCorrection(self, distance) :
        for i in xrange(int(distance*10)) :
            self.motion.walkTo(.10, 0, 0)
            self.motion.walkTo(0, 0, .01*pi)