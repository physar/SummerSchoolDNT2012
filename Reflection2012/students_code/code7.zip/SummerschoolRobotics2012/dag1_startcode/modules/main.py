class main:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")
        
    def start(self):
        self.globals.setProxies()
        self.globals.speechProxy.say("Hello World")
        self.motion.init()
        self.motion.standUp()
        self.tools.cSubscribe()
        image1 = self.tools.getSnapshot()
        self.tools.SaveImage("image1.jpg", image1[0])
        self.vision.getBlobsData(image1)
        
        # blueMinHSV = [110,214,100]
        # blueMaxHSV = [120,238,217]
        # orangeMinHSV = [6,171,72]
        # orangeMaxHSV = [17,238,220]
        # pink1MinHSV = [0,148,77]
        # pink1MaxHSV = [7,237,217]
        # pink2MinHSV = [174,148,77]
        # pink2MaxHSV = [181,237,217]
        
        
        # imageBlue = self.vision.filterImage( image1[0], blueMinHSV, blueMaxHSV)
        # self.tools.SaveImage("imageBlue.jpg",imageBlue)
        # imageOrange = self.vision.filterImage( image1[0], orangeMinHSV, orangeMaxHSV)
        # self.tools.SaveImage("imageOrange.jpg",imageOrange)
        # imagePink = self.vision.filterImage1(image1[0],pink1MinHSV, pink1MaxHSV, pink2MinHSV, pink2MaxHSV)
        # self.tools.SaveImage("imagePink.jpg", imagePink)
        # self.vision.findCircle(imageBlue)
        # self.vision.findCircle(imageOrange)
        # self.vision.findCircle(imagePink)
        
