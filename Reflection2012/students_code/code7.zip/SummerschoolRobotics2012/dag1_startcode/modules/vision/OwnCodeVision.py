    #Filter HSV Image with given values
    def filterImage(self, img, minHSV, maxHSV):
        '''
        Input: HSV Image, 2 List of min and max HSV values 
        Output: Black White Matrix/Image      
        '''
        minScalar = cv.Scalar(minHSV[0], minHSV[1], minHSV[2], 0)
        maxScalar = cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2], 0)
        resultImg = cv.CreateImage((320,240), cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScalar, maxScalar, resultImg)
        cv.Smooth(resultImg, resultImg, cv.CV_MEDIAN, 1)
        resultImg = cv.GetMat(resultImg)
        return resultImg
    
    def filterImage1(self, img, min1HSV, max1HSV, min2HSV, max2HSV):
        min1Scalar = cv.Scalar(min1HSV[0], min1HSV[1], min1HSV[2], 0)
        max1Scalar = cv.Scalar(max1HSV[0], max1HSV[1], max1HSV[2], 0)
        min2Scalar = cv.Scalar(min2HSV[0], min2HSV[1], min2HSV[2], 0)
        max2Scalar = cv.Scalar(max2HSV[0], max2HSV[1], max2HSV[2], 0)
        resultImg = cv.CreateImage((320,240), cv.IPL_DEPTH_8U, 1)
        resultImg1 = cv.CreateImage((320,240), cv.IPL_DEPTH_8U, 1)
        resultImg2 = cv.CreateImage((320,240), cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, min1Scalar, max1Scalar, resultImg1)
        cv.InRangeS(img, min2Scalar, max2Scalar, resultImg2)
        cv.Or(resultImg1,resultImg2,resultImg,mask=None)
        cv.Smooth(resultImg, resultImg, cv.CV_MEDIAN, 1)
        resultImg = cv.GetMat(resultImg)
        return resultImg