import cv, cv2
import numpy as np
import ARimport as ar

ARcode = ar.ARimport()
image = cv.LoadImage("test.png",cv.CV_LOAD_IMAGE_COLOR)
im_array = np.asarray( image[:,:] )
ARcode.setOutputFileName("output.png")
ARcode.setShowOutput(True)
returnint = ARcode.findMarkers(im_array)
output = ARcode.getFoundMarker(0)
print((output.ID, output.x, output.y))