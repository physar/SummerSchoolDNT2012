from naoqi import ALProxy
class globals:
    ipadres = "192.168.1.26"
    
    def setDependencies(self, modules):
        pass
        
    def setProxies(self):
        self.speechProxy = ALProxy("ALTextToSpeech", self.ipadres, 9559)
        self.motProxy = ALProxy("ALMotion", self.ipadres, 9559)
        self.posProxy = ALProxy("ALRobotPose", self.ipadres, 9559)
        self.vidProxy = ALProxy("ALVideoDevice", self.ipadres, 9559)
        self.redBallProxy = ALProxy("ALRedBallTracker", self.ipadres, 9559)