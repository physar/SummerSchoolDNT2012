class main_v1:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        '''self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")'''

    def start(self):
        '''self.globals.setProxies()
        self.motion.init()
        self.tools.cSubscribe()
        self.motion.stiff()
        self.motion.setHead(0,-0.5)'''
        self.motion.stiff()
        self.motion.standUp()
        
        #take picture
        '''(picture, (unimportantstuff_1, unimportantstuff_2)) = self.tools.getSnapshot()
        self.tools.SaveImage("test.png", picture)
        
        #filter blue
        minHSV = [110, 214, 100]
        maxHSV = [120, 230, 217]
        image_blue = self.vision.filterImage(picture, minHSV, maxHSV)
        self.tools.SaveImage("result.png", image_blue)
        
        #Throug extended research at the cost of many fallen Nao's
        #we at the Dutch Nao Team found that the optimal head position is
        #self.motion.setHead(0,-0.5)'''