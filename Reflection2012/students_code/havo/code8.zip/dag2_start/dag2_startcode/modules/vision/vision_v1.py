import cv, cv2
import numpy, math

class vision_v1():    
    globals = None

    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")

    #Filter HSV Image with given values
    def filterImage(self, img, minHSV, maxHSV):
        minScalar = cv.Scalar(minHSV[0], minHSV[1], minHSV[2], 0)
        maxScalar = cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2], 0)
        size = (320, 240)
        resultImg = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScalar, maxScalar, resultImg)
        '''
        Input: HSV Image, 2 List of min and max HSV values 
        Output: Black White Matrix/Image      
        '''
        #return filtImMat
        return resultImg
        
    #Find Circle in a filtered image
    def findCircle(self,imageMat):
        '''
        Input: Black Whit Image
        Return: List of center position of found Circle       
        '''
        '''if circles == None:
            return None
        else:
            return coordinates'''
        pass    
            
    # Proces image to detect color blobs
    def getBlobsData(self, image):
        '''
        Input: Image
        Return: numberOfBlobsFound , [List [center-pixels] of blobs]
        '''
        return blobsFound , blobsList
        
    # Get Average Distance between multiple blobs  
    def calcAvgBlobDistance(self, blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: Avarege Distance in pixels
        '''
        #return Distance
        pass
    
    # Find centre of a Landmark
    def calcMidLandmark(self, blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: center pixel as (x,y)
        '''
        #return center
        pass
        
    # Find the angle between a found Landmark and the Nao
    def calcAngleLandmark(self, center):
        '''
        Input: center pixel, (x,y)
        Output: Angle in radians
        '''    
        #return angle
        pass
    
    # Find the Signature
    def findSignature(self,blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: Signature
        '''
        #return signature
        pass

    