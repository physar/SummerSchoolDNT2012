import time
import math

class main:
    globals = True
    tools = True
    motion = True
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")

    def start(self):
        print 'start'















        '''x = 0
        y = 0
        self.globals.setProxies()
        self.tools.cSubscribe()
        self.globals.speechProxy.say("I'm going to find the ball")
        self.motion.stiff()
        self.motion.standUp()
        self.globals.redBallProxy.startTracker()
        start = time.time()
        while (time.time() - start < 300):
            [x,y,z] = self.globals.redBallProxy.getPosition()
            print 'x,y coord of found ball'
            print x,y
            ball_dist = math.sqrt(x*x+y*y)
            if (y<0 and ball_dist>0):
                ball_angle = -math.acos(y/ball_dist)
            elif (y>0 and ball_dist>0):
                ball_angle = math.acos(y/ball_dist)
            else:
                x = 0
                y = 0
                break
            self.motion.walkTo(0,0,ball_angle)
            if (ball_dist>0.1):
                self.motion.walkTo(0.5*ball_dist,0,0)
            else:
                self.motion.walkTo(ball_dist,0,0)
            x = 0
            y = 0
        self.globals.redBallProxy.stopTracker()'''
        
        
        
        
        '''self.motion.stiff()
        self.globals.speechProxy.say("Text")
        self.motion.walkTo(x,y,angle)'''