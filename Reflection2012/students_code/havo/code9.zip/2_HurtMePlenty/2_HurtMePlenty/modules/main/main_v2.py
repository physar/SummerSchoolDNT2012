class main_v2:
    def setDependencies(self, modules):
        self.maze = modules.getModule("mparser")
        self.astar = modules.getModule("astar")
        self.visu = modules.getModule("visualization")

    def start(self):
        self.visu.init()
        
        #print "Edges: ",edges
        #print "Moves: ",moves
        #self.maze.prettyPrint(edges)
        
        grid_x = 3
        grid_y = 3
        start = (0,0)
        goal = (3,3)
        path = self.astar.findPath(grid_x, grid_y, start, goal)
        print path
        
        
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        '''options.append(moves[position[0]])
            if len(options) == 0:
                print "There's no route."
                break
            else:
                for r in range(len(options)):
                    valueList = []
                    somevalue = grid_x - options[r-1][0][0] + grid_y - options[r-1][0][1]
                    valueList.append(somevalue)
                position = options[valueList.index(max(valueList))]
                print options[valueList.index(max(valueList))]
                options[0].pop(valueList.index(max(valueList)))
                print valueList.index(max(valueList))
                print position
                print "volgende stap"
        
        #later snelste route toevoegen'''
        
        
        
        
        
        
        
        
        self.visu.stop()