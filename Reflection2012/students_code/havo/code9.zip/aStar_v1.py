import math

class aStar_v1:
    def setDependencies(self, modules):
        self.maze = modules.getModule("mparser")
        self.astar = modules.getModule("astar")
        self.visu = modules.getModule("visualization")
    
    def newOpt(self, moves, options, path, values, position, stap, goal):
        neighbours = moves[position]
        for neighbour in neighbours:
            if neighbour in path or neighbour in options:
                pass
            else:
                options.append(neighbour)
                values.append(self.astar.valuelize(neighbour, stap, goal))
        
    def bestOpt(self, options, values):
        return options[values.index(min(values))]
    
    def valuelize(self, option, stap, goal):
        return abs(goal[0]-option[0])+abs(goal[1]-option[1])+stap
    
    def findPath (self, grid_x, grid_y, position, goal):
        values = []
        options = []
        path = [(0,0)]
        stap = 0
        edges, moves = self.maze.parseMaze()
        
        while not position == goal:
            self.astar.newOpt(moves, options, path, values, position, stap, goal)
            position = self.astar.bestOpt(options, values)
            stap = stap + 1
            path.append(options.pop(values.index(min(values))))
            values.remove(min(values))
                    