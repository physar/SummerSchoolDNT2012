import cv, cv2
import numpy, math

class vision_v1():    
    globals = None

    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")

    #Filter HSV Image with given values
    def filterImage(self, img, minHSV, maxHSV):
        minScaler = cv.Scalar(minHSV[0], minHSV[1], minHSV[2])
        maxScaler = cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2])
        size = (320,240)
        resultImg = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScaler, maxScaler, resultImg)
        
        return resultImg
        
    def filterImage_pink(self, img, minHSV, maxHSV, minHSV2, maxHSV2):
        minScaler = cv.Scalar(minHSV[0], minHSV[1], minHSV[2])
        maxScaler = cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2])
        size = (320,240)
        resultImg_1 = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScaler, maxScaler, resultImg_1)
        
        
        minScaler2 = cv.Scalar(minHSV2[0], minHSV2[1], minHSV2[2])
        maxScaler2 = cv.Scalar(maxHSV2[0], maxHSV2[1], maxHSV2[2])
        resultImg_2 = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScaler2, maxScaler2, resultImg_2)
        
        resultImg = cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.Or(resultImg_1,resultImg_2,resultImg)
        
        
        '''
        Input: HSV Image, 2 List of min and max HSV values 
        Output: Black White Matrix/Image      
        '''
        #return filtImMat
        return resultImg
        
    #Find Circle in a filtered image
    def findCircle(self,img):
        img = numpy.asarray(img)
        dp = 2
        minD = 120
        p1 = 255
        p2 = 27
        minS = 8
        maxS = 300
        circles = cv2.HoughCircles(img, cv.CV_HOUGH_GRADIENT, dp, minD, None, p1, p2, minS, maxS)
        
        '''
        Input: Black Whit Image
        Return: List of center position of found Circle       
        '''
        if circles == None:
            return None
        else:
            return circles
            
            
    # Proces image to detect color blobs
    def getBlobsData(self, image):
        '''
        Input: Image
        Return: numberOfBlobsFound , [List [center-pixels] of blobs]
        '''
        #return blobsFound , blobsList
        pass
        
    # Get Average Distance between multiple blobs  
    def calcAvgBlobDistance(self, blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: Avarege Distance in pixels
        '''
        #return Distance
        pass
    
    # Find centre of a Landmark
    def calcMidLandmark(self, blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: center pixel as (x,y)
        '''
        #return center
        pass
        
    # Find the angle between a found Landmark and the Nao
    def calcAngleLandmark(self, center):
        '''
        Input: center pixel, (x,y)
        Output: Angle in radians
        '''    
        #return angle
        pass
    
    # Find the Signature
    def findSignature(self,blobList):
        '''
        Input: [Pink, Blue, Orange]
        Output: Signature
        '''
        #return signature
        pass

    