import cv
import time

class main_v1:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")

    def start(self):
        self.globals.setProxies()
        self.motion.init()
        self.tools.cSubscribe()
        self.motion.stiff()
        self.motion.standUp()
        self.motion.setHead(0,-0.7)
        time.sleep(2)
        endless = 1
        while endless == 1:
            amount_circles = 0
            r = 0
        
            self.motion.walkTo(0.05,0,0)
            
            #take picture
            (img, (camPos, headAngles)) = self.tools.getSnapshot()
            self.tools.SaveImage("test.png", img)
            
            #filter blue
            minHSV = [110, 214, 100]
            maxHSV = [120, 230, 217]
            image_blue = self.vision.filterImage(img, minHSV, maxHSV)
            self.tools.SaveImage("blue.png", image_blue)
            image_blue = cv.GetMat(image_blue)
            bluecircle = self.vision.findCircle(image_blue)
            #print bluecircle
            bluelist = []
            if not bluecircle == None:
                for r in range(len(bluecircle[0])):
                    if 15<bluecircle[0][r][2]<1000:
                        amount_circles = amount_circles + 1
                        bluelist.append(bluecircle[0][r])
                    r = r + 1
        
            #filter orange
            minHSV = [6, 171, 72]
            maxHSV = [17, 238, 220]
            image_orange = self.vision.filterImage(img, minHSV, maxHSV)
            self.tools.SaveImage("orange.png", image_orange)
            image_orange = cv.GetMat(image_orange)
            orangecircle = self.vision.findCircle(image_orange)
            #print orangecircle
            orangelist = []
            if not orangecircle == None:
                for r in range(len(orangecircle[0])):
                    if 15<orangecircle[0][r][2]<1000:
                        amount_circles = amount_circles + 1
                        orangelist.append(orangecircle[0][r])
                    r = r + 1
        
        
            #filter pink
            minHSV = [0, 148, 77]
            maxHSV = [7, 237, 217]
            minHSV2 = [174, 148, 77]
            maxHSV2 = [181, 237, 217]
            image_pink = self.vision.filterImage_pink(img, minHSV, maxHSV, minHSV2, maxHSV2)
            self.tools.SaveImage("pink.png", image_pink)
            image_pink = cv.GetMat(image_pink)
            pinkcircle = self.vision.findCircle(image_pink)
            #print pinkcircle
            pinklist = []
            if not pinkcircle == None:
                for r in range(len(pinkcircle[0])):
                    if 15<pinkcircle[0][r][2]<50:
                        amount_circles = amount_circles + 1
                        pinklist.append(pinkcircle[0][r])
                    r = r + 1
            #print amount_circles
            
            
            if amount_circles == 3:
                if bluelist[0][1] < orangelist[0][1] and bluelist[0][1] < pinklist[0][1]:
                    #print "Blue circle on top, finish"
                    pass
                elif orangelist[0][1] < bluelist[0][1] and orangelist[0][1] < pinklist[0][1]:
                    #print "Orange circle on top, go right"
                    self.motion.walkTo(0,0,-1.5)
                elif pinklist[0][1] < orangelist[0][1] and pinklist[0][1] < bluelist[0][1]:
                    #print "Pink circle on top, go left"
                    self.motion.walkTo(0,0,1.5)
                else:
                    #print error
                    pass