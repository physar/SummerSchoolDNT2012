import cv, cv2
import numpy, math

class main_v1:
    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.motion = modules.getModule("motion")
        self.tools = modules.getModule("tools")
        self.vision = modules.getModule("vision")

    def start(self):
        self.globals.setProxies()
        self.motion.init()
        self.tools.cSubscribe()
        self.motion.standUp()
        richting = 0
        
        while not richting == "straight":
            self.motion.standUp()
            self.motion.setHead(0,-0.5)
            (img, _) = self.tools.getSnapshot()
            x = self.vision.getBlobsData(img)
            if x[0] == None:
                self.motion.walkTo(0.15, 0, 0)
            else:
                distance = self.vision.calcAvgBlobDistance2(x[1], x[0])
                if distance == 1:
                    center = self.vision.calcMidLandmark(x[1], x[0])
                    angle = self.vision.calcAngleLandmark(center, x[0])
                    self.motion.walkTo(0,0,angle)
                else:
                    pass
                distance = self.vision.calcAvgBlobDistance(x[1], x[0])
                if distance == 1:
                    #Welke kleur is boven en hoe sta ik ervoor
                    upColor = self.vision.findUpColor(x[1])
                    self.globals.speechProxy.say("This is:")
                    self.globals.speechProxy.say(upColor)
                    print angle
                    
                    #Draai en zeg wat je gaat doen
                    richting = self.vision.whichWay(upColor)
                    if richting == "left, yeah, sure":
                        turnangle = 1.57
                        self.motion.walkTo(0,0, turnangle)
                    elif richting == "right, that means I am on the right track, hahahaha":
                        turnangle = -1.57
                        self.motion.walkTo(0,0, turnangle)
                    else:
                        richting = "straight"
                elif distance == 0:
                    self.motion.walkTo(0.15, 0, 0)   
            