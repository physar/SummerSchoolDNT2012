class main:
    def setDependencies(self, modules):
        self.globals=modules.getModule("globals")
        self.motion=modules.getModule("motion")
        self.tools=modules.getModule("tools")
        
    def start(self):
        self.globals.setProxies()
        self.tools.cSubscribe()
        self.motion.init()
        self.motion.stiff()
        self.motion.standUp()
        self.tools.getSnapshot()
        self.tools.SaveImage("test.jpg", img[0])