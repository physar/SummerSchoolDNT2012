import cv, cv2
import numpy, math

class vision_v1():    
    globals = None

    def setDependencies(self, modules):
        self.globals = modules.getModule("globals")
        self.vision = modules.getModule("vision")
        self.tools = modules.getModule("tools")
        self.tools = modules.getModule("motion")

    #Filter HSV Image with given values
    def filterImage(self, img, minHSV, maxHSV):
        size=(320,240)
        minScalar=cv.Scalar(minHSV[0], minHSV[1], minHSV[2])
        maxScalar=cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2])
        
        filtImMat=cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScalar, maxScalar, filtImMat)
        
        cv.Smooth(filtImMat, filtImMat, cv.CV_MEDIAN, 9)
        filtImMat=cv.GetMat(filtImMat)
        
        return filtImMat
        
    def filterImage2(self, img, minHSV, minHSV2, maxHSV, maxHSV2):
        size=(320,240)
        minScalar=cv.Scalar(minHSV[0], minHSV[1], minHSV[2])
        maxScalar=cv.Scalar(maxHSV[0], maxHSV[1], maxHSV[2])
        filtImMat=cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScalar, maxScalar, filtImMat)
        
        minScalar=cv.Scalar(minHSV2[0], minHSV2[1], minHSV2[2])
        maxScalar=cv.Scalar(maxHSV2[0], maxHSV2[1], maxHSV2[2])
        filtImMat2=cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        filtImMat3=cv.CreateImage(size, cv.IPL_DEPTH_8U, 1)
        cv.InRangeS(img, minScalar, maxScalar, filtImMat2)
        cv.Or(filtImMat, filtImMat2, filtImMat3)
        
        cv.Smooth(filtImMat3, filtImMat3, cv.CV_MEDIAN, 9)
        filtImMat3=cv.GetMat(filtImMat3)
        return filtImMat3
        
    #Find Circle in a filtered image
    def findCircle(self,imageMat):
        '''
        Input: Black Whit Image
        Return: List of center position of found Circle       
        '''
        if circles == None:
            return None
        else:
            return coordinates
            
            
    # Proces image to detect color blobs
    def getBlobsData(self, img):
        img2 = self.vision.filterImage2(img, [0, 148, 77], [174, 148, 77], [7, 237, 217], [181, 237, 217])
        img3 = self.vision.filterImage(img, [110,214,100], [120, 230, 270])
        img4 = self.vision.filterImage(img, [6, 171, 72], [17, 238, 220])
        
        #Give circle coordinates
        pic1 = numpy.asarray(img2)
        pic2 = numpy.asarray(img3)
        pic3 = numpy.asarray(img4)
        
        #Define blobsFound and define blobsList
        blobsFound = 0
        blobsList = []
        circles = cv2.HoughCircles(pic1, cv.CV_HOUGH_GRADIENT, 2, 120, None, 255, 27, 8, 300)
        if not circles == None:
            blobsFound=blobsFound + 1
            blobsList.append([circles[0][0][0], circles[0][0][1]])
        else:
            pass
        
        circles2 = cv2.HoughCircles(pic2, cv.CV_HOUGH_GRADIENT, 2, 120, None, 255, 27, 8, 300)
        if not circles2 == None:
            blobsFound=blobsFound + 1
            blobsList.append([circles2[0][0][0], circles2[0][0][1]])
        else:
            pass
            
        circles3 = cv2.HoughCircles(pic3, cv.CV_HOUGH_GRADIENT, 2, 120, None, 255, 27, 8, 300)
        if not circles3 == None:
            blobsFound=blobsFound + 1
            blobsList.append([circles3[0][0][0], circles3[0][0][1]])
        else:
            pass
            
        if blobsFound == 0:
            blobsFound = None
        else:
            pass
        
        if blobsFound == 0:
            return blobsFound
        else:
            return blobsFound, blobsList
        
        
    # Get Average Distance between multiple blobs  
    def calcAvgBlobDistance(self, blobList, blobsFound):
        
        #voorwaarde:
        if blobsFound == 3:
            #bereken distance tussen oranje en roze
            xdistance = blobList[2][0] - blobList[0][0]
            ydistance = blobList[2][1] - blobList[0][1]
            
            ydistance=abs(ydistance)
            xdistance=abs(xdistance)
            if 70<xdistance:
                rightDistance = 1
            elif 70<ydistance:
                rightDistance = 1
            else:
                rightDistance = 0
        else:
            rightDistance = 0
        
        return rightDistance
        
    def calcAvgBlobDistance2(self, blobList, blobsFound):
        
        #voorwaarde:
        if blobsFound == 3:
            #bereken distance tussen oranje en roze
            xdistance = blobList[2][0] - blobList[0][0]
            ydistance = blobList[2][1] - blobList[0][1]
            
            ydistance=abs(ydistance)
            xdistance=abs(xdistance)
            if 10<xdistance:
                rightDistance = 1
            elif 10<ydistance:
                rightDistance = 1
            else:
                rightDistance = 0
        else:
            rightDistance = 0
        
        return rightDistance
    
    # Find centre of a Landmark
    def calcMidLandmark(self, blobList, x):
        
        if x == None:
            return None
        else:
            print 'bloblist: ', blobList
            maxx = max(blobList[0][0], blobList[1][0], blobList[2][0])
            minx = min(blobList[0][0], blobList[1][0], blobList[2][0])
            x = (minx + maxx)/2
            
            maxy = max(blobList[0][1], blobList[1][1], blobList[2][1])
            miny = min(blobList[0][1], blobList[1][1], blobList[2][1])
            y = (miny + maxy)/2
            
            center = x, y
            
        return center
        
    # Find the angle between a found Landmark and the Nao
    def calcAngleLandmark(self, center, x):
        if x == None:
            return None
        else:
            som = center[0] - 160
            angle = som * 0.0038
            angle = - angle
            return angle
    
    # Find the Signature
    def findUpColor(self,blobList):
        
        maxy = min(blobList[0][1], blobList[1][1], blobList[2][1])
        if maxy == blobList[0][1]:
            a = "pink"
            return a
        elif maxy == blobList[1][1]:
            b = "blue"
            return b
        else:
            c = "orange"
            return c
            
    def whichWay(self, upColor):
        if upColor == "pink":
            richting = "left, yeah, sure"
        elif upColor == "blue":
            richting = "oh wait, I am already at the finish! AW YEAH! I'm going to be a whealty robot. First I want to thank Geert en Luuk for taking care of me. Second of all, I must say that the people who helped us writing the code to get trough this maze were really nice and helpful. Thank you. Maikel. Goodbye cruel Robolab!"
        elif upColor == "orange":
            richting = "right, that means I am on the right track, hahahaha"
        
        self.globals.speechProxy.say("So, I should go")
        self.globals.speechProxy.say(richting)
        if upColor == "blue":
            self.motion.walkTo(0, 0, 1.57)
            self.motion.kill()
        else:
            pass
            
        
        return richting
        